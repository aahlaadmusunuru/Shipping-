window.onload = init;

function init(){
  // Controls
  const fullScreenControl = new ol.control.FullScreen();

  const overViewMapControl = new ol.control.OverviewMap({
    tipLabel: 'Custom Overview Map',
    collapsed: true,
    layers: [
      new ol.layer.Tile({
        source: new ol.source.OSM()
      })
    ]
  });
  const scaleLineControl = new ol.control.ScaleLine({

    units: 'metric',
    minWidth: 200,
    bar: true,
    steps: 4,
    text: true

  } );
  const zoomSliderControl = new ol.control.ZoomSlider();
  const zoomToExtentControl = new ol.control.ZoomToExtent();

  const map = new ol.Map({
    interactions: ol.interaction.defaults({mouseWheelZoom:false}),

    view: new ol.View({
      center: [11946323.686849108,2419495.5059337737],
      zoom: 10,
      maxZoom: 12,
      minZoom: 8,
      rotation: 0
    }),
    layers: [
      new ol.layer.Tile({
        source: new ol.source.OSM(),
        visible: true,
        title: 'OSMStandard'

      })
    ],
    target: 'js-map',
    keyboardEventTarget: document,
    controls: ol.control.defaults().extend([
      fullScreenControl,
      overViewMapControl,
      scaleLineControl,
      zoomSliderControl,
      zoomToExtentControl

    ])
  })


  // Vector Layers
  // Central EU Countries GeoJSON VectorImage Layer
   // Styling of vector features
  // Style for polygons
  const fillStyle = new ol.style.Fill({
    color: [40, 119, 247, 1]
  })
  const fillStylee = new ol.style.Fill({
    color: [255, 0, 0, 1]
  })
  const marinecorridosStyle = new ol.style.Fill({
    color: [0,0,0,0.1, 1]
  })

  const merineunitestyle = new ol.style.Fill({
    color: [0,0,0,0.3, 1]
  })
  // Style for lines
  const strokeStyle = new ol.style.Stroke({
    color: [30, 30, 31, 1],
    width: 1.2,
    lineCap: 'square',
    lineJoin: 'bevel',
    lineDash: [1, 1]
  })
  const strokeStyleE = new ol.style.Stroke({
    color: [51, 204, 51, 1],
    width: 3,
    lineCap: 'square',
    lineJoin: 'bevel',
    lineDash: [1, 1]
  })

  const QuangNinh = new ol.layer.VectorImage({
    source: new ol.source.Vector({
      url: './GISdata/Quang Ninh map.geojson',
      format: new ol.format.GeoJSON()
    }),
    visible: true,
    title: 'QuangNinh',
    style: new ol.style.Style({
      fill: fillStyle,
      stroke: strokeStyle,
    })
  })
  map.addLayer(QuangNinh);
  const merineunites = new ol.layer.VectorImage({
    source: new ol.source.Vector({
      url: './GISdata/merineunites.geojson',
      format: new ol.format.GeoJSON()
    }),
    visible: true,
    title: 'merineunites',
    style: new ol.style.Style({
      fill: merineunitestyle,

    })
  })

  map.addLayer(merineunites);


  const Ports = new ol.layer.VectorImage({
    source: new ol.source.Vector({
      url: './GISdata/Ports.geojson',
      format: new ol.format.GeoJSON()
    }),
    visible: true,
    title: 'Ports',
    style: new ol.style.Style({
      fill: fillStylee,

    })
  })

  map.addLayer(Ports);

  const Ship_navi = new ol.layer.VectorImage({
    source: new ol.source.Vector({
      url: './GISdata/Ship_navi.geojson',
      format: new ol.format.GeoJSON()
    }),
    visible: true,

    title: 'Ship_navi',
    style: new ol.style.Style({
      fill: fillStylee,
      stroke: strokeStyleE,
    })
  })
  map.addLayer(Ship_navi);

}
